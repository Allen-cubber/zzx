%% Part 2: 频率分辨率 Δf = 0.5Hz

% --- 4.1. 重新确定采样参数 ---
% fs 和 Ts 保持不变，因为 f_max 没有变
delta_f_new = 0.5; % 新的频率分辨率 (Hz)
N_new = fs / delta_f_new; % 新的最少采样点数

fprintf('--- Part 2: 频率分辨率 Δf = 0.5Hz ---\n');
fprintf('新的频率分辨率 Δf = %.1f Hz\n', delta_f_new);
fprintf('4.1. 确定的最大采样间隔 Ts 保持不变，为 %.4f s\n', Ts);
fprintf('     确定的最少采样点数 N_new = fs/Δf = %d\n\n', N_new);

% --- 4.2. 重新采样并绘制幅频特性 ---
% 创建新的时间向量
t_new = (0:N_new-1) * Ts;
% 对连续信号进行采样
xt_new = cos(2*pi*f1*t_new) + sin(2*pi*f2*t_new) + cos(2*pi*f3*t_new);

% 执行DFT
Xk_new = fft(xt_new,400);

% 计算单边频谱
P2_new = abs(Xk_new/N_new);
P1_new = P2_new(1:N_new/2+1);
P1_new(2:end-1) = 2*P1_new(2:end-1);

% 创建新的频率轴
f_axis_new = (0:(N_new/2)) * fs / N_new;

% 绘图
figure('Name', '频谱分析 (Δf = 0.5Hz)');
plot(f_axis_new, P1_new);
grid on;
title('信号x(t)的幅频特性 (频率分辨率 \Deltaf = 0.5Hz)');
xlabel('模拟频率 (Hz)');
ylabel('幅度');
xlim([0, 120]);
xticks(0:10:120);

