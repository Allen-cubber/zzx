% 清理工作区
clear;
clc;
close all;

% 定义信号 x[n] = cos(0.48*pi*n) + cos(0.52*pi*n)

%% 步骤 1: 取一个周期，计算其DFT
N1 = 50;
n1 = 0:N1-1;
x1 = cos(0.48*pi*n1) + cos(0.52*pi*n1);

% 计算 N1 点 DFT
X1 = fft(x1);
mag_X1 = abs(X1);
% 频率轴 (归一化频率)
f1 = n1/N1;

%% 步骤 2: 将步骤1中的x[n]补零至100点，计算其DFT
N2 = 100;
% 在 x1 后面补 50 个零
x2 = [x1, zeros(1, N2 - N1)];
n2 = 0:N2-1;

% 计算 N2 点 DFT
X2 = fft(x2);
mag_X2 = abs(X2);
% 频率轴 (归一化频率)
f2 = n2/N2;


%% 步骤 3: 对x[n]取 0<=n<=99，计算其DFT
N3 = 100;
n3 = 0:N3-1;
% 直接生成 100 个点的信号，这正好是两个周期
x3 = cos(0.48*pi*n3) + cos(0.52*pi*n3);

% 计算 N3 点 DFT
X3 = fft(x3);
mag_X3 = abs(X3);
% 频率轴 (归一化频率)
f3 = n3/N3;

%% 绘图
figure('Name', 'DFT 分析', 'Position', [100, 100, 800, 900]);

% 绘制图1
subplot(3, 1, 1);
stem(f1, mag_X1, 'b', 'filled');
title('1) 50点周期信号的DFT (N=50)');
xlabel('归一化频率 (f)');
ylabel('|X(k)|');
grid on;
xlim([0, 1]); % 显示完整的归一化频率

% 绘制图2
subplot(3, 1, 2);
plot(f2, mag_X2, 'r-o', 'MarkerSize', 4);
title('2) 50点信号补零到100点的DFT (N=100)');
xlabel('归一化频率 (f)');
ylabel('|X(k)|');
grid on;
xlim([0, 1]);

% 绘制图3
subplot(3, 1, 3);
stem(f3, mag_X3, 'g', 'filled');
title('3) 100点周期信号的DFT (N=100)');
xlabel('归一化频率 (f)');
ylabel('|X(k)|');
grid on;
xlim([0, 1]);