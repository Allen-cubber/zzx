%% Part 1: 频率分辨率 Δf = 1Hz

clear; clc; close all;

% --- 1. 确定采样参数 ---
f1 = 100; % Hz
f2 = 50;  % Hz
f3 = 25;  % Hz
f_max = 100; % 信号最大频率

% 根据奈奎斯特理论，确定最小采样频率
fs = 2 * f_max; % 采样频率 (Hz)，取临界值
Ts = 1/fs;      % 最大采样间隔 (s)

% 根据要求的频率分辨率，确定最少采样点数
delta_f = 1;    % 要求的频率分辨率 (Hz)
N = fs / delta_f; % 所需的最少采样点数

fprintf('--- Part 1: 频率分辨率 Δf = 1Hz ---\n');
fprintf('信号最高频率 f_max = %.1f Hz\n', f_max);
fprintf('根据奈奎斯特理论, 采样频率 fs >= %.1f Hz\n', 2*f_max);
fprintf('我们选择 fs = %.1f Hz\n', fs);
fprintf('1. 确定的最大采样间隔 Ts = 1/fs = %.4f s\n', Ts);
fprintf('   确定的最少采样点数 N = fs/Δf = %d\n\n', N);

% --- 2. 采样并绘制幅频特性 ---
% 创建时间向量
t = (0:N-1) * Ts;
% 对连续信号进行采样
xt = cos(2*pi*f1*t) + sin(2*pi*f2*t) + cos(2*pi*f3*t);

% 执行DFT (使用FFT算法)
Xk = fft(xt,200);

% 计算双边频谱的幅值，并进行归一化
P2 = abs(Xk/N);
% 计算单边频谱 (0 到 fs/2)
P1 = P2(1:N/2+1);
P1(2:end-1) = 2*P1(2:end-1); % 非直流和奈奎斯特频率分量幅值加倍

% 创建频率轴 (对应模拟频率)
f_axis = (0:(N/2)) * fs / N; % f = k * (fs/N)

% 绘图
figure('Name', '频谱分析 (Δf = 1Hz)');
stem(f_axis, P1);
grid on;
title('信号x(t)的幅频特性 (频率分辨率 \Deltaf = 1Hz)');
xlabel('模拟频率 (Hz)'); % 关键：横坐标用模拟频率
ylabel('幅度');
xlim([0, 120]); % 限制x轴范围，以便更清晰地观察
xticks(0:10:120); % 设置x轴刻度