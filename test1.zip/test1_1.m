% 清理工作区和命令行
clear;
clc;
close all;

%% 实验设置
% 原始信号 x[n] = cos(πn/10) + sin(πn/6) + cos(2πn/5)

%% 要求1 & 2: 固定矩形窗，不同窗长 (线性幅度)

N_values = [20, 60, 120];
figure('Name', '影响: 矩形窗长度 (线性幅度)', 'NumberTitle', 'off');

for i = 1:length(N_values)
    N = N_values(i);
    n = 0:N-1;
    x = cos(pi*n/10) + sin(pi*n/6) + cos(2*pi*n/5);
    w_rect = rectwin(N);
    x_w = x .* w_rect';
    
    N_fft = N; % 不进行补零
    X_w = fft(x_w, N_fft);
    
    % --- 关键修改部分 1: 计算线性幅度 ---
    % 将 20*log10(abs(...)) 改为直接 abs(...)
    mag_linear = abs(fftshift(X_w));
    
    % 为了便于比较，将最大幅度归一化到1
    if max(mag_linear) > 0
        mag_linear = mag_linear / max(mag_linear);
    end
    % ----------------------------------------
    
    f = (-N_fft/2 : N_fft/2 - 1) / N_fft;
    
    subplot(3, 1, i);
    stem(f, mag_linear, 'b', 'filled', 'MarkerSize', 4);
    hold on;
    plot(f, mag_linear, 'r--');
    hold off;
    
    grid on; ax = gca; ax.XGrid = 'off';
    
    title(['矩形窗, N = ', num2str(N), ' (', num2str(N), '点FFT)']);
    xlabel('归一化频率 (cycles/sample)');
    
    % --- 关键修改部分 2: 修改Y轴标签和范围 ---
    ylabel('幅度 (线性归一化)');
    ylim([0, 1.1]); % 设置Y轴范围为0到1.1
    % ------------------------------------------
end
sgtitle('图1: 不同窗长对频谱的影响 (线性幅度)');


%% 要求3: 固定窗长，不同窗函数 (线性幅度)

N_fixed = 60;
window_funcs = {@rectwin, @hann, @hamming, @blackman};
window_names = {'矩形窗', '汉宁窗', '海明窗', '布莱克曼窗'};

figure('Name', '影响: 不同窗函数 (线性幅度)', 'NumberTitle', 'off');

n_fixed = 0:N_fixed-1;
x_fixed = cos(pi*n_fixed/10) + sin(pi*n_fixed/6) + cos(2*pi*n_fixed/5);

for i = 1:length(window_funcs)
    win_func = window_funcs{i};
    w = win_func(N_fixed);
    x_w_fixed = x_fixed .* w';
    
    N_fft_fixed = N_fixed;
    X_w_fixed = fft(x_w_fixed, N_fft_fixed);
    
    % --- 关键修改部分 1: 计算线性幅度 ---
    mag_linear_fixed = abs(fftshift(X_w_fixed));
    if max(mag_linear_fixed) > 0
        mag_linear_fixed = mag_linear_fixed / max(mag_linear_fixed);
    end
    % ----------------------------------------
    
    f_fixed = (-N_fft_fixed/2 : N_fft_fixed/2 - 1) / N_fft_fixed;
    
    subplot(2, 2, i);
    stem(f_fixed, mag_linear_fixed, 'b', 'filled', 'MarkerSize', 4);
    hold on;
    plot(f_fixed, mag_linear_fixed, 'r--');
    hold off;
    
    grid on; ax = gca; ax.XGrid = 'off';
    
    xlabel('归一化频率 (cycles/sample)');
    
    % --- 关键修改部分 2: 修改Y轴标签和范围 ---
    ylabel('幅度 (线性归一化)');
    ylim([0, 1.1]);
    % ------------------------------------------
end
sgtitle(['图2: 不同窗函数对频谱的影响 (线性幅度, N=60)']);